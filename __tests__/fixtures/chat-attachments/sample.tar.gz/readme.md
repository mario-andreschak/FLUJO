# Seeds
Keep them dry.